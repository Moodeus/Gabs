<?php
$nav_current_page = $current_page ?? basename($_SERVER['PHP_SELF']);
$orders_active = ($nav_current_page === 'orders.php') ? 'active' : '';
$settings_active = ($nav_current_page === 'settings.php') ? 'active' : '';
?>
<div class="header-bar">
    <div class="logo-container">
        <?php include __DIR__ . '/../brand_logo.php'; ?>
    </div>
    <nav class="navbar">
        <div class="main-nav" id="main-nav-links">
            <a href="welcome.php" class="<?= ($nav_current_page === 'welcome.php') ? 'active' : '' ?>">Dashboard</a>
            <a href="orders.php" class="<?= $orders_active ?>">Orders</a>
            <a href="settings.php" class="<?= $settings_active ?>">Settings</a>
            <a href="logout.php" class="logout-link">Logout</a>
        </div>
        <button class="hamburger" id="hamburger-button" aria-label="Toggle navigation menu">&#9776;</button>
    </nav>
</div>
